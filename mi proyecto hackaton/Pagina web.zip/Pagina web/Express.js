const express = require('express');
const bcrypt = require('bcryptjs');
const app = express();

// Middleware para parsear los datos del formulario
app.use(express.urlencoded({ extended: true }));

// Ruta para el login
app.post('/login', async (req, res) => {
    const { username, password } = req.body;

    // Aquí deberías buscar al usuario en la base de datos y verificar la contraseña
    const user = { username: 'user', password: '$2a$10$....' }; // Contraseña cifrada (bcrypt)
    
    const match = await bcrypt.compare(password, user.password);

    if (match) {
        res.send('Login exitoso');
    } else {
        res.send('Credenciales incorrectas');
    }
});

// Iniciar el servidor
app.listen(3000, () => {
    console.log('Servidor corriendo en http://localhost:3000');
});
// GET
app.get('/data', (req, res) => {
    res.json({ message: 'GET request received' });
});

// POST
app.post('/data', (req, res) => {
    const data = req.body;
    res.json({ message: 'Data received', data });
});

// PUT
app.put('/data/:id', (req, res) => {
    const { id } = req.params;
    const updatedData = req.body;
    res.json({ message: `Data ${id} updated`, updatedData });
});

// DELETE
app.delete('/data/:id', (req, res) => {
    const { id } = req.params;
    res.json({ message: `Data ${id} deleted` });
});

