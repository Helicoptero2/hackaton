document.getElementById('login-form')?.addEventListener('submit', function(event) {
    event.preventDefault();

    const username = (document.getElementById('username') as HTMLInputElement).value;
    const password = (document.getElementById('password') as HTMLInputElement).value;

    if (username === 'admin' && password === 'admin123') {
        alert('Login exitoso');
    } else {
        alert('Usuario o contraseña incorrectos');
    }
});
